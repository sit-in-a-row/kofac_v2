const imageUpload1 = document.getElementById("trainImgInput");
const imageUpload2 = document.getElementById("testImgInput");
const submit = document.getElementById('submit');

var trainImg = document.getElementById('trainImgDisplay');
var testImg = document.getElementById('testImgDisplay');

var isTrainImgUpload = false;
var isTestImgUpload = false;

var traditionalMode = false;
var machineLearningMode = false;

function checkMode() {
    var selectElement = document.getElementById("imageClassification");
    var selectedOption = selectElement.value;

    traditionalMode = selectedOption === 'traditional';
    machineLearningMode = selectedOption === 'machineLearning';

    console.log(traditionalMode ? '전통적인 이미지 분류 모드 설정 완료' : machineLearningMode ? '머신러닝 이미지 분류 모드 설정 완료' : '모드 확인 불가');
}

function loadImage(event, imgNum) {
    const reader = new FileReader();
    reader.onload = (e) => {
        const img = document.createElement('img');
        img.src = e.target.result;
        img.style.maxWidth = '100%';

        if (imgNum === 1) {
            trainImg = img;
            const trainImgContainer = document.getElementById('trainImgDisplay');
            trainImgContainer.innerHTML = '';
            trainImgContainer.appendChild(img);
        } else if (imgNum === 2) {
            testImg = img;
            const testImgContainer = document.getElementById('testImgDisplay');
            testImgContainer.innerHTML = '';
            testImgContainer.appendChild(img);
        }
    };
    reader.readAsDataURL(event.target.files[0]);
}

// 전통적인 이미지 분류

function getAverageRGB(img) {
    var canvas = document.createElement('canvas');
    var ctx = canvas.getContext('2d');
    canvas.width = img.width;
    canvas.height = img.height;
    ctx.drawImage(img, 0, 0);

    var imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    var data = imageData.data;
    var r = 0, g = 0, b = 0;

    for (var i = 0; i < data.length; i += 4) {
        r += data[i];
        g += data[i + 1];
        b += data[i + 2];
    }

    r = Math.round(r / (data.length / 4));
    g = Math.round(g / (data.length / 4));
    b = Math.round(b / (data.length / 4));

    return {r, g, b};
}

function isSimilar(rgb1, rgb2) {
    var threshold = 30; // 역치값 조정해서 전통적인 모델 민감도 조절
    return (Math.abs(rgb1.r - rgb2.r) < threshold &&
            Math.abs(rgb1.g - rgb2.g) < threshold &&
            Math.abs(rgb1.b - rgb2.b) < threshold);
}

// 머신러닝 이미지 분류

function classifyImage(img) {
    return new Promise((resolve, reject) => {
        mobilenet.load().then(model => {
            model.classify(img).then(predictions => {
                resolve(predictions);
            }).catch(err => {
                reject(err);
            });
        });
    });
}

function areSimilar(preds1, preds2) {
    const classes1 = preds1.map(p => p.className);
    const classes2 = preds2.map(p => p.className);

    return classes1.some(className => classes2.includes(className));
}

// 결과 출력

function displayResult(similarity, mode) {
    // const resultMessage = similarity ? '같은 이미지입니다' : '다른 이미지입니다';
    // alert(`${resultMessage}_${mode}`);

    const resultImage = document.getElementById("resultImage");
    resultImage.style.display = "block";
    resultImage.src = `imgs/classify_${similarity ? 'same' : 'different'}.png`;

    // resultImage.addEventListener('click', function() {
    //     resultImage.classList.add('fade-out'); 
    //     setTimeout(function() {
    //         resultImage.style.display = "none";
    //         resultImage.classList.remove('fade-out'); 
    //     }, 1000); 
    // });

    setTimeout(function() {
        resultImage.style.display = "none";
        resultImage.classList.remove('fade-out'); 
    }, 1000); 
}

async function traditionalClassifier() {
    const rgbTrain = getAverageRGB(trainImg);
    const rgbTest = getAverageRGB(testImg);

    if (isTrainImgUpload && isTestImgUpload) {
        var similarity = isSimilar(rgbTrain, rgbTest);
        displayResult(similarity, 'traditional');
    }
}

async function machineLearningClassifier() {
    if (isTrainImgUpload && isTestImgUpload) {
        const predictions1 = await classifyImage(trainImg);
        const predictions2 = await classifyImage(testImg);

        const similar = areSimilar(predictions1, predictions2);
        displayResult(similar, 'machineLearning');
    }
}

// 이벤트 리스너들

imageUpload1.addEventListener('change', (event) => {
    isTrainImgUpload = false;
    loadImage(event, 1);
    isTrainImgUpload = true;
});

imageUpload2.addEventListener('change', (event) => {
    isTestImgUpload = false;
    loadImage(event, 2);
    isTestImgUpload = true;
});

submit.addEventListener("click", () => {
    checkMode();
    if (traditionalMode) {
        traditionalClassifier();
    } else if (machineLearningMode) {
        machineLearningClassifier();
    } else {
        console.log("모드 확인 불가_classify");
    }
});
